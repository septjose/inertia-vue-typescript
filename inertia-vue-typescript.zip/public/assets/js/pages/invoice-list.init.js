var invoice_new_obj,
    qty = 0,
    rate = 0,
    Invoices=[],
    /*Invoices = [
        {
            invoice_no: "24301901",
            logo_img: "assets/images/logo-light.png",
            customer: "Themesbrand",
            email: "themesbrand@vixon.com",
            createDate: "28 Mar, 2023",
            dueDate: "06 Apr, 2023",
            invoice_amount: 381.76,
            status: "Paid",
            billing_address: {
                full_name: "Themesbrand",
                address: "5114 Adipiscing St. Puno United States 46782",
                phone: "(926) 817-7835",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Quamar Payne",
                address: "534-1477 Non, Av. Bury St. Edmunds France 10846",
                phone: "(926) 817-7835",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Sweatshirt for Men (Pink)",
                    product_details: "Graphic Print Men & Women Sweatshirt",
                    rates: (rate = 119.99),
                    quantity: (qty = 2),
                    amount: rate * qty,
                },
                {
                    product_name: "Noise NoiseFit Endure Smart Watch",
                    product_details:
                        "32.5mm (1.28 Inch) TFT Color Touch Display",
                    rates: (rate = 94.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
                {
                    product_name: "350 ml Glass Grocery Container",
                    product_details:
                        "Glass Grocery Container (Pack of 3, White)",
                    rates: (rate = 24.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 381.76,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 359.96,
                estimated_tex: 64.79,
                discount: 107.99,
                shipping_charge: 65,
                total_amount: 381.76,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301902",
            logo_img: "assets/images/logo-light.png",
            customer: "Ayaan Bowen",
            email: "ayaan@vixon.com",
            createDate: "21 Mar, 2023",
            dueDate: "21 Mar, 2023",
            invoice_amount: 359.77,
            status: "Unpaid",
            billing_address: {
                full_name: "Ayaan Bowen",
                address:
                    "P.O. Box 900 Ireland, 6694 Ullamcorper Avenue Port Pirie 37176",
                phone: "1-862-423-3347",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Quamar Payne",
                address: "7288 Dignissim Rd. Villa Alegre Germany 891315",
                phone: "1-862-423-3347",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Sweatshirt for Men (Pink)",
                    product_details: "Graphic Print Men & Women Sweatshirt",
                    rates: (rate = 119.99),
                    quantity: (qty = 2),
                    amount: rate * qty,
                },
                {
                    product_name: "Noise NoiseFit Endure Smart Watch",
                    product_details:
                        "32.5mm (1.28 Inch) TFT Color Touch Display",
                    rates: (rate = 94.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 359.77,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 334.97,
                estimated_tex: 60.29,
                discount: 100.49,
                shipping_charge: 65,
                total_amount: 359.77,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301903",
            logo_img: "assets/images/logo-light.png",
            customer: "Zachary Stokes",
            email: "zachary@vixon.com",
            createDate: "16 Mar, 2023",
            dueDate: "21 Mar, 2023",
            invoice_amount: 276.18,
            status: "Paid",
            billing_address: {
                full_name: "Zachary Stokes",
                address: "Ap #957-7519 Vel, Belgium St. Diêm Điền 88188-296",
                phone: "1-634-649-4101",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "MacKensie Peterson",
                address: "572-7561 Tempus Ave Alajuela Spain 86558",
                phone: "1-634-649-4101",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Sweatshirt for Men (Pink)",
                    product_details: "Graphic Print Men & Women Sweatshirt",
                    rates: (rate = 119.99),
                    quantity: (qty = 2),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 276.18,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 239.98,
                estimated_tex: 43.2,
                discount: 71.99,
                shipping_charge: 65,
                total_amount: 276.18,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301904",
            logo_img: "assets/images/logo-light.png",
            customer: "Nelson Schaden",
            email: "nelson@vixon.com",
            createDate: "27 Feb, 2023",
            dueDate: "05 Mar, 2023",
            invoice_amount: 509.34,
            status: "Pending",
            billing_address: {
                full_name: "Nelson Schaden",
                address: "983-8399 Egestas, Rd Spain. Penza 6596",
                phone: "(922) 264-4841",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Emerson Riggs",
                address: "916-4370 Aliquet Avenue Nordhorn Spain 3200",
                phone: "(922) 264-4841",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Sweatshirt for Men (Pink)",
                    product_details: "Graphic Print Men & Women Sweatshirt",
                    rates: (rate = 119.99),
                    quantity: (qty = 2),
                    amount: rate * qty,
                },
                {
                    product_name: "Noise NoiseFit Endure Smart Watch",
                    product_details:
                        "32.5mm (1.28 Inch) TFT Color Touch Display",
                    rates: (rate = 94.99),
                    quantity: (qty = 2),
                    amount: rate * qty,
                },
                {
                    product_name: "350 ml Glass Grocery Container",
                    product_details:
                        "Glass Grocery Container (Pack of 3, White)",
                    rates: (rate = 24.99),
                    quantity: (qty = 3),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 509.34,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 504.93,
                estimated_tex: 90.89,
                discount: 151.48,
                shipping_charge: 65,
                total_amount: 509.34,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301905",
            logo_img: "assets/images/logo-light.png",
            customer: "Ophelia Steuber",
            email: "ophelia@vixon.com",
            createDate: "06 Apr, 2023",
            dueDate: "12 Apr, 2023",
            invoice_amount: 170.58,
            status: "Unpaid",
            billing_address: {
                full_name: "Ophelia Steuber",
                address: "Ap #552-1397 Ac Rd Germany. Barmouth 8574",
                phone: "1-434-874-6805",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Britanni Daniel",
                address:
                    "P.O. Box 998, 9293 Quisque Avenue Puerto Montt Poland 82862",
                phone: "1-434-874-6805",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Noise NoiseFit Endure Smart Watch",
                    product_details:
                        "32.5mm (1.28 Inch) TFT Color Touch Display",
                    rates: (rate = 94.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
                {
                    product_name: "350 ml Glass Grocery Container",
                    product_details:
                        "Glass Grocery Container (Pack of 3, White)",
                    rates: (rate = 24.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 170.58,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 119.98,
                estimated_tex: 21.6,
                discount: 35.99,
                shipping_charge: 65,
                total_amount: 170.58,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301906",
            logo_img: "assets/images/logo-light.png",
            customer: "Sarai Schmidt",
            email: "sarai@vixon.com",
            createDate: "20 Feb, 2023",
            dueDate: "26 Feb, 2023",
            invoice_amount: 254.18,
            status: "Paid",
            billing_address: {
                full_name: "Sarai Schmidt",
                address: "5642 Aliquam, Avenue Zielona Costa Rica Góra 21204",
                phone: "1-546-878-8131",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Salvador Carney",
                address: "715-6973 Non St. Samara Peru 10513",
                phone: "1-546-878-8131",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Sweatshirt for Men (Pink)",
                    product_details: "Graphic Print Men & Women Sweatshirt",
                    rates: (rate = 119.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
                {
                    product_name: "Noise NoiseFit Endure Smart Watch",
                    product_details:
                        "32.5mm (1.28 Inch) TFT Color Touch Display",
                    rates: (rate = 94.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 254.18,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 214.98,
                estimated_tex: 38.7,
                discount: 64.49,
                shipping_charge: 65,
                total_amount: 254.18,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301907",
            logo_img: "assets/images/logo-light.png",
            customer: "Deondre Huel",
            email: "deondre@vixon.com",
            createDate: "13 Feb, 2023",
            dueDate: "19 Feb, 2023",
            invoice_amount: 86.99,
            status: "Paid",
            billing_address: {
                full_name: "Deondre Huel",
                address:
                    "P.O. Box 332 Italy, 5256 Dignissim St. Juazeiro do Norte 646442",
                phone: "(587) 848-3170",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Kieran Holland",
                address:
                    "150-7530 Egestas Av. Panchià Russian Federation 16807",
                phone: "(587) 848-3170",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "350 ml Glass Grocery Container",
                    product_details:
                        "Glass Grocery Container (Pack of 3, White)",
                    rates: (rate = 24.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 86.99,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 24.99,
                estimated_tex: 4.5,
                discount: 7.5,
                shipping_charge: 65,
                total_amount: 86.99,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301908",
            logo_img: "assets/images/logo-light.png",
            customer: "Nelson Schaden",
            email: "nelson@vixon.com",
            createDate: "01 Feb, 2023",
            dueDate: "07 Feb, 2023",
            invoice_amount: 213.49,
            status: "Unpaid",
            billing_address: {
                full_name: "Nelson Schaden",
                address: "2935 Senectus Av. Tvedestrand Germany 66479",
                phone: "(287) 406-9128",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Yoshio Skinner",
                address: "101-9784 Metus Rd. Minitonas Mexico 19-154",
                phone: "(287) 406-9128",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Sweatshirt for Men (Pink)",
                    product_details: "Graphic Print Men & Women Sweatshirt",
                    rates: (rate = 119.99),
                    quantity: (qty = 2),
                    amount: rate * qty,
                },
                {
                    product_name: "Noise NoiseFit Endure Smart Watch",
                    product_details:
                        "32.5mm (1.28 Inch) TFT Color Touch Display",
                    rates: (rate = 94.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
                {
                    product_name: "350 ml Glass Grocery Container",
                    product_details:
                        "Glass Grocery Container (Pack of 3, White)",
                    rates: (rate = 24.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 415.96,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 359.96,
                estimated_tex: 44.99,
                discount: 53.99,
                shipping_charge: 65,
                total_amount: 415.96,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301909",
            logo_img: "assets/images/logo-light.png",
            customer: "Prezy Mark",
            email: "prezy@vixon.com",
            createDate: "29 Jan, 2023",
            dueDate: "06 Feb, 2023",
            invoice_amount: 381.76,
            status: "Paid",
            billing_address: {
                full_name: "Prezy Mark",
                address: "414-240 Odio. Rd Vietnam. Louisville 41715",
                phone: "1-681-342-7158",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Linus Pitts",
                address: "Ap #280-7347 Libero. Rd. Yurimaguas Italy 881484",
                phone: "1-681-342-7158",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Sweatshirt for Men (Pink)",
                    product_details: "Graphic Print Men & Women Sweatshirt",
                    rates: (rate = 119.99),
                    quantity: (qty = 2),
                    amount: rate * qty,
                },
                {
                    product_name: "Noise NoiseFit Endure Smart Watch",
                    product_details:
                        "32.5mm (1.28 Inch) TFT Color Touch Display",
                    rates: (rate = 94.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
                {
                    product_name: "350 ml Glass Grocery Container",
                    product_details:
                        "Glass Grocery Container (Pack of 3, White)",
                    rates: (rate = 24.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 381.76,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 359.96,
                estimated_tex: 64.79,
                discount: 107.99,
                shipping_charge: 65,
                total_amount: 381.76,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301910",
            logo_img: "assets/images/logo-light.png",
            customer: "Domenic Dach",
            email: "domenic@vixon.com",
            createDate: "17 Jan, 2023",
            dueDate: "23 Jan, 2023",
            invoice_amount: 276.18,
            status: "Refund",
            billing_address: {
                full_name: "Domenic Dach",
                address: "Ap #322-2982 Lacinia Road India Moss 309511",
                phone: "1-514-596-7650",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Otto Farrell",
                address: "Ap #827-2319 Eu Ave Bima Norway 1663",
                phone: "1-514-596-7650",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Sweatshirt for Men (Pink)",
                    product_details: "Graphic Print Men & Women Sweatshirt",
                    rates: (rate = 119.99),
                    quantity: (qty = 2),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 276.18,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 239.98,
                estimated_tex: 43.2,
                discount: 71.99,
                shipping_charge: 65,
                total_amount: 276.18,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
        {
            invoice_no: "24301911",
            logo_img: "assets/images/logo-light.png",
            customer: "Paki Edwards",
            email: "sdwards@vixon.com",
            createDate: "17 Jan, 2023",
            dueDate: "23 Jan, 2023",
            invoice_amount: 170.58,
            status: "Paid",
            billing_address: {
                full_name: "Paki Edwards",
                address: "2935 Senectus Av. Tvedestrand Germany 66479",
                phone: "(287) 406-9128",
                tax: "123456789",
            },
            shipping_address: {
                full_name: "Yoshio Skinner",
                address: "101-9784 Metus Rd. Minitonas Mexico 19-154",
                phone: "(287) 406-9128",
                tax: "123456789",
            },
            products: [
                {
                    product_name: "Noise NoiseFit Endure Smart Watch",
                    product_details:
                        "32.5mm (1.28 Inch) TFT Color Touch Display",
                    rates: (rate = 94.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
                {
                    product_name: "350 ml Glass Grocery Container",
                    product_details:
                        "Glass Grocery Container (Pack of 3, White)",
                    rates: (rate = 24.99),
                    quantity: (qty = 1),
                    amount: rate * qty,
                },
            ],
            payment_details: {
                payment_method: "VISA",
                card_holder_name: "Reese Jacobs",
                card_number: "4024007179348742",
                total_amount: 170.58,
            },
            company_details: {
                legal_registration_no: "987654",
                email: "vixon@themesbrand.com",
                website: "www.themesbrand.com",
                contact_no: "+(01) 234 6789",
            },
            order_summary: {
                sub_total: 119.98,
                estimated_tex: 21.6,
                discount: 35.99,
                shipping_charge: 65,
                total_amount: 170.58,
            },
            notes: "All accounts are to be paid within 7 days from receipt of invoice. To be paid by cheque or credit card or direct payment online. If account is not paid within 7 days the credits details supplied as confirmation of work undertaken will be charged the agreed quoted fee noted above.",
            sign_img: "assets/images/invoice-signature.svg",
        },
    ],*/
    checkAll = document.getElementById("checkAll"),
    perPage =
        (checkAll &&
            (checkAll.onclick = function () {
                for (
                    var e = document.querySelectorAll(
                            '.form-check-all input[type="checkbox"]'
                        ),
                        t = document.querySelectorAll(
                            '.form-check-all input[type="checkbox"]:checked'
                        ).length,
                        a = 0;
                    a < e.length;
                    a++
                )
                    (e[a].checked = this.checked),
                        e[a].checked
                            ? e[a].closest("tr").classList.add("table-active")
                            : e[a]
                                  .closest("tr")
                                  .classList.remove("table-active"),
                        e[a].closest("tr").classList.contains("table-active"),
                        0 < t
                            ? document
                                  .getElementById("remove-actions")
                                  .classList.add("d-none")
                            : document
                                  .getElementById("remove-actions")
                                  .classList.remove("d-none");
            }),
        (null === localStorage.getItem("invoices-list") &&
            null === localStorage.getItem("new_data_object")) ||
            (null === localStorage.getItem("invoices-list") &&
            null !== localStorage.getItem("new_data_object")
                ? ((invoice_new_obj = JSON.parse(
                      localStorage.getItem("new_data_object")
                  )),
                  Invoices.push(invoice_new_obj),
                  localStorage.removeItem("new_data_object"))
                : ((Invoices = []),
                  (Invoices = JSON.parse(
                      localStorage.getItem("invoices-list")
                  )),
                  null !== localStorage.getItem("new_data_object") &&
                      ((invoice_new_obj = JSON.parse(
                          localStorage.getItem("new_data_object")
                      )),
                      Invoices.push(invoice_new_obj),
                      localStorage.removeItem("new_data_object")),
                  localStorage.removeItem("invoices-list"))),
        Array.from(Invoices).forEach(function (e) {
            let t;
            switch (e.status) {
                case "Paid":
                    t = "success";
                    break;
                case "Pending":
                    t = "warning";
                    break;
                case "Unpaid":
                case "Refund":
                    t = "danger";
            }
            e =
                '<tr>        <td>            <div class="form-check">                <input class="form-check-input" type="checkbox" name="chk_child" value="#TBS' +
                e.invoice_no +
                '">                <label class="form-check-label"></label>            </div>        </td>        <td class="invoice_id"><a href="apps-invoices-overview.html">#TBS' +
                e.invoice_no +
                '</a></td>        <td class="customer_name">' +
                e.customer +
                '</td>        <td class="email">' +
                e.email +
                '</td>        <td class="create_date">' +
                e.createDate +
                '</td>        <td class="due_date">' +
                e.dueDate +
                '</td>        <td class="amount">$' +
                e.invoice_amount +
                '</td>        <td class="status"><span class="badge bg-' +
                t +
                "-subtle text-" +
                t +
                '">' +
                e.status +
                '</span></td>        <td>            <ul class="d-flex gap-2 list-unstyled mb-0">                <li>                    <a href="javascript:void(0);" class="btn btn-subtle-primary btn-icon btn-sm" onclick="ViewInvoice(this);"  data-view-id="' +
                e.invoice_no +
                '"><i class="ph-eye"></i></a>                </li>                <li>                    <a href="javascript:void(0);" class="btn btn-subtle-secondary btn-icon btn-sm" onclick="EditInvoice(this);" data-edit-id="' +
                e.invoice_no +
                '"><i class="ph-pencil"></i></a>                </li>                <li>                    <a href="#deleteRecordModal" data-bs-toggle="modal" class="btn btn-subtle-danger btn-icon btn-sm remove-item-btn"><i class="ph-trash"></i></a>                </li>            </ul>        </td>    </tr>';
            document.getElementById("invoice-list-data").innerHTML += e;
        }),
        10),
    options = {
        valueNames: [
            "invoice_id",
            "customer_name",
            "email",
            "amount",
            "create_date",
            "due_date",
            "status",
        ],
        page: perPage,
        pagination: !0,
        plugins: [ListPagination({ left: 2, right: 2 })],
    },
    invoiceList = new List("invoiceList", options).on("updated", function (e) {
        0 == e.matchingItems.length
            ? (document.getElementsByClassName("noresult")[0].style.display =
                  "block")
            : (document.getElementsByClassName("noresult")[0].style.display =
                  "none");
        var t = 1 == e.i,
            a = e.i > e.matchingItems.length - e.page;
        document.querySelector(".pagination-prev.disabled") &&
            document
                .querySelector(".pagination-prev.disabled")
                .classList.remove("disabled"),
            document.querySelector(".pagination-next.disabled") &&
                document
                    .querySelector(".pagination-next.disabled")
                    .classList.remove("disabled"),
            t &&
                document
                    .querySelector(".pagination-prev")
                    .classList.add("disabled"),
            a &&
                document
                    .querySelector(".pagination-next")
                    .classList.add("disabled"),
            e.matchingItems.length <= perPage
                ? (document.getElementById("pagination-element").style.display =
                      "none")
                : (document.getElementById("pagination-element").style.display =
                      "flex"),
            0 < e.matchingItems.length
                ? (document.getElementsByClassName(
                      "noresult"
                  )[0].style.display = "none")
                : (document.getElementsByClassName(
                      "noresult"
                  )[0].style.display = "block");
    }),
    removeBtns =
        (document
            .querySelector(".pagination-next")
            .addEventListener("click", function () {
                document.querySelector(".pagination.listjs-pagination") &&
                    document
                        .querySelector(".pagination.listjs-pagination")
                        .querySelector(".active") &&
                    null !=
                        document
                            .querySelector(".pagination.listjs-pagination")
                            .querySelector(".active").nextElementSibling &&
                    document
                        .querySelector(".pagination.listjs-pagination")
                        .querySelector(".active")
                        .nextElementSibling.children[0].click();
            }),
        document
            .querySelector(".pagination-prev")
            .addEventListener("click", function () {
                document.querySelector(".pagination.listjs-pagination") &&
                    document
                        .querySelector(".pagination.listjs-pagination")
                        .querySelector(".active") &&
                    null !=
                        document
                            .querySelector(".pagination.listjs-pagination")
                            .querySelector(".active").previousSibling &&
                    document
                        .querySelector(".pagination.listjs-pagination")
                        .querySelector(".active")
                        .previousSibling.children[0].click();
            }),
        document.getElementsByClassName("remove-item-btn"));
function ViewInvoice(e) {
    e = e.getAttribute("data-view-id");
    localStorage.setItem("invoices-list", JSON.stringify(Invoices)),
        localStorage.setItem("option", "view-invoice"),
        localStorage.setItem("invoice_no", e),
        window.location.assign("apps-invoices-overview.html");
}
function EditInvoice(e) {
    e = e.getAttribute("data-edit-id");
    localStorage.setItem("invoices-list", JSON.stringify(Invoices)),
        localStorage.setItem("option", "edit-invoice"),
        localStorage.setItem("invoice_no", e),
        window.location.assign("apps-invoices-create.html");
}
function isCheckboxCheck() {
    Array.from(document.getElementsByName("chk_child")).forEach(function (a) {
        a.addEventListener("change", function (e) {
            1 == a.checked
                ? e.target.closest("tr").classList.add("table-active")
                : e.target.closest("tr").classList.remove("table-active");
            var t = document.querySelectorAll(
                '[name="chk_child"]:checked'
            ).length;
            e.target.closest("tr").classList.contains("table-active"),
                0 < t
                    ? document
                          .getElementById("remove-actions")
                          .classList.remove("d-none")
                    : document
                          .getElementById("remove-actions")
                          .classList.add("d-none");
        });
    });
}
function refreshCallbacks() {
    Array.from(removeBtns).forEach(function (e) {
        e.addEventListener("click", function (e) {
            e.target.closest("tr").children[1].innerText,
                (itemId = e.target.closest("tr").children[1].innerText);
            e = invoiceList.get({ invoice_id: itemId });
            Array.from(e).forEach(function (e) {
                var t = (deleteId = new DOMParser().parseFromString(
                    e._values.invoice_id,
                    "text/html"
                )).body.firstElementChild;
                deleteId.body.firstElementChild.innerHTML == itemId &&
                    document
                        .getElementById("delete-record")
                        .addEventListener("click", function () {
                            invoiceList.remove("invoice_id", t.outerHTML),
                                document
                                    .getElementById("deleteRecord-close")
                                    .click();
                        });
            });
        });
    });
}
function deleteMultiple() {
    ids_array = [];
    var e = document.getElementsByName("chk_child");
    for (i = 0; i < e.length; i++)
        1 == e[i].checked && ids_array.push(e[i].value);
    "undefined" != typeof ids_array && 0 < ids_array.length
        ? Swal.fire({
              title: "Are you sure?",
              text: "You won't be able to revert this!",
              icon: "warning",
              showCancelButton: !0,
              confirmButtonClass: "btn btn-primary w-xs me-2 mt-2",
              cancelButtonClass: "btn btn-danger w-xs mt-2",
              confirmButtonText: "Yes, delete it!",
              buttonsStyling: !1,
              showCloseButton: !0,
          }).then(function (e) {
              if (e.value) {
                  for (i = 0; i < ids_array.length; i++)
                      invoiceList.remove(
                          "invoice_id",
                          `<a href="apps-invoices-overview.html">${ids_array[i]}</a>`
                      );
                  document
                      .getElementById("remove-actions")
                      .classList.add("d-none"),
                      (document.getElementById("checkAll").checked = !1),
                      Swal.fire({
                          title: "Deleted!",
                          text: "Your data has been deleted.",
                          icon: "success",
                          confirmButtonClass: "btn btn-info w-xs mt-2",
                          buttonsStyling: !1,
                      });
              }
          })
        : Swal.fire({
              title: "Please select at least one checkbox",
              confirmButtonClass: "btn btn-info",
              buttonsStyling: !1,
              showCloseButton: !0,
          });
}
refreshCallbacks(), isCheckboxCheck();
