<script setup lang="ts">
    import MyComponent from '@/Pages/Prueba.vue'
</script>

<template>
    <MyComponent title="hola" description="Esta es una prueba"></MyComponent>
</template>