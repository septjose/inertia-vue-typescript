<template>
           <BaseComponent>
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="card-title font-weight-bold"><p class="text-muted">Bienvenido de nuevo</p></h4>
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Inicio</a></li>
                                <li class="breadcrumb-item active">Aforo y bombas Guzmán</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">

                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3">
                    <div class="card shadow-lg rounded border-0" style="background-color: white">
                        <div class="card-header" style="background-color: white">
                           <button type="button" class="btn-info float-end fs-xxs" style="border: none; background-color: transparent;" aria-label="Información">
                                    <i class="bi bi-info-circle"></i>
                                </button>

                            <h6 class="card-title mb-0">Pozos</h6>
                        </div>
                        <div class="card-body p-3 text-center">
                            <div class="mx-auto avatar-lg mb-0">
                                <img src="/logo_abg.png" alt=""
                                    class="img-fluid rounded-circle">
                            </div>
                            <h5 class="card-title mb-1">200 pozos</h5>

                        </div>
                        <div class="card-footer text-center" style="background-color: white">
                             <a href="/pozos" class="btn btn-primary btn-block">Ver más</a>
                        </div>
                    </div>
                </div><!-- end col -->
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3">
                    <div class="card shadow-lg rounded border-0" style="background-color: white">
                        <div class="card-header" style="background-color: white">
                           <button type="button" class="btn-info float-end fs-xxs" style="border: none; background-color: transparent;" aria-label="Información">
                                    <i class="bi bi-info-circle"></i>
                                </button>
                            <h6 class="card-title mb-0">Clientes</h6>
                        </div>
                        <div class="card-body p-3 text-center">
                            <div class="mx-auto avatar-lg mb-0">
                                <img src="/logo_abg.png" alt=""
                                    class="img-fluid rounded-circle">
                            </div>
                            <h5 class="card-title mb-1">100 clientes</h5>

                        </div>
                        <div class="card-footer text-center" style="background-color: white">
                             <a href="/clientes" class="btn btn-primary btn-block">Ver más</a>
                        </div>
                    </div>
                </div><!-- end col -->
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3">
                    <div class="card shadow-lg rounded border-0" style="background-color: white">
                        <div class="card-header" style="background-color: white">
                           <button type="button" class="btn-info float-end fs-xxs" style="border: none; background-color: transparent;" aria-label="Información">
                                    <i class="bi bi-info-circle"></i>
                                </button>
                            <h6 class="card-title mb-0">Usuarios</h6>
                        </div>
                        <div class="card-body p-3 text-center">
                            <div class="mx-auto avatar-lg mb-0">
                                <img src="/logo_abg.png" alt=""
                                    class="img-fluid rounded-circle">
                            </div>
                            <h5 class="card-title mb-1">50 Usuarios</h5>

                        </div>
                        <div class="card-footer text-center" style="background-color: white">
                             <a href="/usuarios" class="btn btn-primary btn-block">Ver más</a>
                        </div>
                    </div>
                </div><!-- end col -->
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3">
                    <div class="card shadow-lg rounded border-0" style="background-color: white">
                        <div class="card-header" style="background-color: white">
                           <button type="button" class="btn-info float-end fs-xxs" style="border: none; background-color: transparent;" aria-label="Información">
                                    <i class="bi bi-info-circle"></i>
                                </button>
                            <h6 class="card-title mb-0">Reportes</h6>
                        </div>
                        <div class="card-body p-3 text-center">
                            <div class="mx-auto avatar-lg mb-0">
                                <img src="/logo_abg.png" alt=""
                                    class="img-fluid rounded-circle">
                            </div>
                            <h5 class="card-title mb-1">50 reportes</h5>

                        </div>
                        <div class="card-footer text-center" style="background-color: white">
                             <a href="/ver_reportes" class="btn btn-primary btn-block">Ver más</a>
                        </div>
                    </div>
                </div><!-- end col -->
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3">
                    <div class="card shadow-lg rounded border-0" style="background-color: white">
                        <div class="card-header" style="background-color: white">
                           <button type="button" class="btn-info float-end fs-xxs" style="border: none; background-color: transparent;" aria-label="Información">
                                    <i class="bi bi-info-circle"></i>
                                </button>
                            <h6 class="card-title mb-0">Presupuestos</h6>
                        </div>
                        <div class="card-body p-3 text-center">
                            <div class="mx-auto avatar-lg mb-0">
                                <img src="/logo_abg.png" alt=""
                                    class="img-fluid rounded-circle">
                            </div>
                            <h5 class="card-title mb-1">50 Presupuestos</h5>

                        </div>
                        <div class="card-footer text-center" style="background-color: white">
                             <a href="/ver_presupuestos" class="btn btn-primary btn-block">Ver más</a>
                        </div>
                    </div>
                </div><!-- end col -->
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3">
                    <div class="card shadow-lg rounded border-0" style="background-color: white">
                        <div class="card-header" style="background-color: white">
                           <button type="button" class="btn-info float-end fs-xxs" style="border: none; background-color: transparent;" aria-label="Información">
                                    <i class="bi bi-info-circle"></i>
                                </button>
                            <h6 class="card-title mb-0">Comunicados</h6>
                        </div>
                        <div class="card-body p-3 text-center">
                            <div class="mx-auto avatar-lg mb-0">
                                <img src="/logo_abg.png" alt=""
                                    class="img-fluid rounded-circle">
                            </div>
                            <h5 class="card-title mb-1">50 Comunicados</h5>
                        </div>
                        <div class="card-footer text-center" style="background-color: white">
                             <a href="/ver_comunicados" class="btn btn-primary btn-block">Ver más</a>
                        </div>
                    </div>
                </div><!-- end col -->
            </div><!-- end row -->    
           </BaseComponent>
                      
  </template>

  <script>
  import BaseComponent from '/resources/js/Pages/Welcome.vue';
  
  export default {
    components: {
      BaseComponent,
    },
  };
  </script>
